﻿namespace Client
{
	partial class Client
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
			this.createOrder = new System.Windows.Forms.DataGridView();
			this.Symbol = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BuySell = new System.Windows.Forms.DataGridViewComboBoxColumn();
			this.Qty = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Send = new System.Windows.Forms.DataGridViewButtonColumn();
			this.gvOrderBook = new System.Windows.Forms.DataGridView();
			this.MyBidQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MktBidQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.PriceOB = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MyAskQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MktAskQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.gvOrderHistory = new System.Windows.Forms.DataGridView();
			this.Buyer = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Seller = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SymbolH = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.QtyH = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.PriceH = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.lblInfo = new System.Windows.Forms.Label();
			this.loginInfo = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.createOrder)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.gvOrderBook)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.gvOrderHistory)).BeginInit();
			this.SuspendLayout();
			// 
			// createOrder
			// 
			dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
			dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
			this.createOrder.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
			this.createOrder.BackgroundColor = System.Drawing.Color.White;
			this.createOrder.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(51)))), ((int)(((byte)(102)))));
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
			dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.createOrder.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
			this.createOrder.ColumnHeadersHeight = 28;
			this.createOrder.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Symbol,
            this.BuySell,
            this.Qty,
            this.Price,
            this.Send});
			dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle8.BackColor = System.Drawing.Color.White;
			dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Black;
			dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Black;
			dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.createOrder.DefaultCellStyle = dataGridViewCellStyle8;
			this.createOrder.EnableHeadersVisualStyles = false;
			this.createOrder.Location = new System.Drawing.Point(29, 69);
			this.createOrder.Name = "createOrder";
			dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle9.BackColor = System.Drawing.Color.White;
			dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle9.ForeColor = System.Drawing.Color.Black;
			dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.Black;
			dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.createOrder.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
			this.createOrder.RowHeadersVisible = false;
			dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle10.BackColor = System.Drawing.Color.Silver;
			dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
			dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.Black;
			this.createOrder.RowsDefaultCellStyle = dataGridViewCellStyle10;
			this.createOrder.Size = new System.Drawing.Size(262, 150);
			this.createOrder.TabIndex = 3;
			this.createOrder.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.createOrder_CellClick);
			this.createOrder.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.createOrder_CellContentClick);
			this.createOrder.KeyDown += new System.Windows.Forms.KeyEventHandler(this.createOrder_KeyDown);
			// 
			// Symbol
			// 
			this.Symbol.DataPropertyName = "SymbolA";
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle3.NullValue = "StockA";
			dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.Symbol.DefaultCellStyle = dataGridViewCellStyle3;
			this.Symbol.HeaderText = "Symbol";
			this.Symbol.Name = "Symbol";
			this.Symbol.ReadOnly = true;
			this.Symbol.Width = 50;
			// 
			// BuySell
			// 
			dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
			dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
			this.BuySell.DefaultCellStyle = dataGridViewCellStyle4;
			this.BuySell.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.BuySell.HeaderText = "Buy/Sell";
			this.BuySell.Items.AddRange(new object[] {
            "Buy",
            "Sell"});
			this.BuySell.Name = "BuySell";
			this.BuySell.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			this.BuySell.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
			this.BuySell.Width = 60;
			// 
			// Qty
			// 
			dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			this.Qty.DefaultCellStyle = dataGridViewCellStyle5;
			this.Qty.HeaderText = "Qty";
			this.Qty.Name = "Qty";
			this.Qty.Width = 50;
			// 
			// Price
			// 
			dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			this.Price.DefaultCellStyle = dataGridViewCellStyle6;
			this.Price.HeaderText = "Price";
			this.Price.Name = "Price";
			this.Price.Width = 50;
			// 
			// Send
			// 
			dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle7.BackColor = System.Drawing.Color.White;
			dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
			this.Send.DefaultCellStyle = dataGridViewCellStyle7;
			this.Send.HeaderText = "";
			this.Send.MinimumWidth = 10;
			this.Send.Name = "Send";
			this.Send.Text = "Send";
			this.Send.UseColumnTextForButtonValue = true;
			this.Send.Width = 50;
			// 
			// gvOrderBook
			// 
			this.gvOrderBook.AllowUserToAddRows = false;
			this.gvOrderBook.AllowUserToDeleteRows = false;
			dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle11.ForeColor = System.Drawing.Color.Black;
			dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.Black;
			this.gvOrderBook.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
			this.gvOrderBook.BackgroundColor = System.Drawing.Color.White;
			this.gvOrderBook.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(51)))), ((int)(((byte)(102)))));
			dataGridViewCellStyle12.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle12.ForeColor = System.Drawing.Color.White;
			dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.Black;
			dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.gvOrderBook.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
			this.gvOrderBook.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.gvOrderBook.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MyBidQty,
            this.MktBidQty,
            this.PriceOB,
            this.MyAskQty,
            this.MktAskQty});
			this.gvOrderBook.EnableHeadersVisualStyles = false;
			this.gvOrderBook.Location = new System.Drawing.Point(325, 69);
			this.gvOrderBook.Name = "gvOrderBook";
			this.gvOrderBook.ReadOnly = true;
			this.gvOrderBook.RowHeadersVisible = false;
			dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle18.BackColor = System.Drawing.Color.Silver;
			dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.Black;
			this.gvOrderBook.RowsDefaultCellStyle = dataGridViewCellStyle18;
			this.gvOrderBook.Size = new System.Drawing.Size(339, 150);
			this.gvOrderBook.TabIndex = 4;
			// 
			// MyBidQty
			// 
			this.MyBidQty.DataPropertyName = "MyBidQty";
			dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			this.MyBidQty.DefaultCellStyle = dataGridViewCellStyle13;
			this.MyBidQty.HeaderText = "My Bid Qty";
			this.MyBidQty.Name = "MyBidQty";
			this.MyBidQty.ReadOnly = true;
			this.MyBidQty.Width = 75;
			// 
			// MktBidQty
			// 
			this.MktBidQty.DataPropertyName = "MktBidQty";
			dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			this.MktBidQty.DefaultCellStyle = dataGridViewCellStyle14;
			this.MktBidQty.HeaderText = "Mkt Bid Qty";
			this.MktBidQty.Name = "MktBidQty";
			this.MktBidQty.ReadOnly = true;
			this.MktBidQty.Width = 73;
			// 
			// PriceOB
			// 
			this.PriceOB.DataPropertyName = "PriceOB";
			dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			this.PriceOB.DefaultCellStyle = dataGridViewCellStyle15;
			this.PriceOB.HeaderText = "Price";
			this.PriceOB.Name = "PriceOB";
			this.PriceOB.ReadOnly = true;
			this.PriceOB.Width = 50;
			// 
			// MyAskQty
			// 
			this.MyAskQty.DataPropertyName = "MyAskQty";
			dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			this.MyAskQty.DefaultCellStyle = dataGridViewCellStyle16;
			this.MyAskQty.HeaderText = "My Ask Qty";
			this.MyAskQty.Name = "MyAskQty";
			this.MyAskQty.ReadOnly = true;
			this.MyAskQty.Width = 70;
			// 
			// MktAskQty
			// 
			this.MktAskQty.DataPropertyName = "MktAskQty";
			dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			this.MktAskQty.DefaultCellStyle = dataGridViewCellStyle17;
			this.MktAskQty.HeaderText = "Mkt Ask Qty";
			this.MktAskQty.Name = "MktAskQty";
			this.MktAskQty.ReadOnly = true;
			this.MktAskQty.Width = 75;
			// 
			// gvOrderHistory
			// 
			this.gvOrderHistory.AllowUserToAddRows = false;
			this.gvOrderHistory.AllowUserToDeleteRows = false;
			dataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			dataGridViewCellStyle19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle19.ForeColor = System.Drawing.Color.Black;
			this.gvOrderHistory.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle19;
			this.gvOrderHistory.BackgroundColor = System.Drawing.Color.White;
			this.gvOrderHistory.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(51)))), ((int)(((byte)(102)))));
			dataGridViewCellStyle20.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle20.ForeColor = System.Drawing.Color.White;
			dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			dataGridViewCellStyle20.SelectionForeColor = System.Drawing.Color.Black;
			dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.gvOrderHistory.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle20;
			this.gvOrderHistory.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Buyer,
            this.Seller,
            this.SymbolH,
            this.QtyH,
            this.PriceH});
			this.gvOrderHistory.EnableHeadersVisualStyles = false;
			this.gvOrderHistory.Location = new System.Drawing.Point(31, 262);
			this.gvOrderHistory.Name = "gvOrderHistory";
			dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle26.BackColor = System.Drawing.Color.White;
			dataGridViewCellStyle26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle26.ForeColor = System.Drawing.Color.Black;
			dataGridViewCellStyle26.SelectionBackColor = System.Drawing.Color.LightGray;
			dataGridViewCellStyle26.SelectionForeColor = System.Drawing.Color.Black;
			dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.gvOrderHistory.RowHeadersDefaultCellStyle = dataGridViewCellStyle26;
			this.gvOrderHistory.RowHeadersVisible = false;
			dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle27.BackColor = System.Drawing.Color.Silver;
			dataGridViewCellStyle27.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			dataGridViewCellStyle27.SelectionForeColor = System.Drawing.Color.Black;
			this.gvOrderHistory.RowsDefaultCellStyle = dataGridViewCellStyle27;
			this.gvOrderHistory.Size = new System.Drawing.Size(253, 133);
			this.gvOrderHistory.TabIndex = 5;
			// 
			// Buyer
			// 
			this.Buyer.DataPropertyName = "BuyerH";
			dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			this.Buyer.DefaultCellStyle = dataGridViewCellStyle21;
			this.Buyer.HeaderText = "Buyer";
			this.Buyer.Name = "Buyer";
			this.Buyer.ReadOnly = true;
			this.Buyer.Width = 50;
			// 
			// Seller
			// 
			this.Seller.DataPropertyName = "SellerH";
			dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			this.Seller.DefaultCellStyle = dataGridViewCellStyle22;
			this.Seller.HeaderText = "Seller";
			this.Seller.Name = "Seller";
			this.Seller.ReadOnly = true;
			this.Seller.Width = 50;
			// 
			// SymbolH
			// 
			this.SymbolH.DataPropertyName = "SymbolH";
			dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			this.SymbolH.DefaultCellStyle = dataGridViewCellStyle23;
			this.SymbolH.HeaderText = "Symbol";
			this.SymbolH.Name = "SymbolH";
			this.SymbolH.ReadOnly = true;
			this.SymbolH.Width = 50;
			// 
			// QtyH
			// 
			this.QtyH.DataPropertyName = "QtyH";
			dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			this.QtyH.DefaultCellStyle = dataGridViewCellStyle24;
			this.QtyH.HeaderText = "Qty";
			this.QtyH.Name = "QtyH";
			this.QtyH.ReadOnly = true;
			this.QtyH.Width = 50;
			// 
			// PriceH
			// 
			this.PriceH.DataPropertyName = "PriceH";
			dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			this.PriceH.DefaultCellStyle = dataGridViewCellStyle25;
			this.PriceH.HeaderText = "Price";
			this.PriceH.Name = "PriceH";
			this.PriceH.ReadOnly = true;
			this.PriceH.Width = 50;
			// 
			// lblInfo
			// 
			this.lblInfo.AutoSize = true;
			this.lblInfo.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(51)))), ((int)(((byte)(102)))));
			this.lblInfo.Location = new System.Drawing.Point(34, 9);
			this.lblInfo.Name = "lblInfo";
			this.lblInfo.Size = new System.Drawing.Size(11, 16);
			this.lblInfo.TabIndex = 6;
			this.lblInfo.Text = " ";
			// 
			// loginInfo
			// 
			this.loginInfo.AutoSize = true;
			this.loginInfo.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.loginInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(51)))), ((int)(((byte)(102)))));
			this.loginInfo.Location = new System.Drawing.Point(494, 9);
			this.loginInfo.Name = "loginInfo";
			this.loginInfo.Size = new System.Drawing.Size(0, 16);
			this.loginInfo.TabIndex = 7;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(51)))), ((int)(((byte)(102)))));
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.White;
			this.label1.Location = new System.Drawing.Point(31, 41);
			this.label1.MinimumSize = new System.Drawing.Size(260, 25);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(260, 25);
			this.label1.TabIndex = 9;
			this.label1.Text = "Create Order";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(51)))), ((int)(((byte)(102)))));
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.White;
			this.label2.Location = new System.Drawing.Point(325, 41);
			this.label2.MinimumSize = new System.Drawing.Size(339, 25);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(339, 25);
			this.label2.TabIndex = 10;
			this.label2.Text = "Market Order Book";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(51)))), ((int)(((byte)(102)))));
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.ForeColor = System.Drawing.Color.White;
			this.label3.Location = new System.Drawing.Point(34, 234);
			this.label3.MinimumSize = new System.Drawing.Size(250, 25);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(250, 25);
			this.label3.TabIndex = 11;
			this.label3.Text = "Market Trades";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// Client
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.AliceBlue;
			this.ClientSize = new System.Drawing.Size(686, 406);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.loginInfo);
			this.Controls.Add(this.lblInfo);
			this.Controls.Add(this.gvOrderHistory);
			this.Controls.Add(this.gvOrderBook);
			this.Controls.Add(this.createOrder);
			this.Name = "Client";
			this.Text = "Client";
			((System.ComponentModel.ISupportInitialize)(this.createOrder)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.gvOrderBook)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.gvOrderHistory)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.DataGridView gvOrderBook;
		private System.Windows.Forms.DataGridView gvOrderHistory;
		private System.Windows.Forms.DataGridViewTextBoxColumn Buyer;
		private System.Windows.Forms.DataGridViewTextBoxColumn Seller;
		private System.Windows.Forms.DataGridViewTextBoxColumn SymbolH;
		private System.Windows.Forms.DataGridViewTextBoxColumn QtyH;
		private System.Windows.Forms.DataGridViewTextBoxColumn PriceH;
		private System.Windows.Forms.Label lblInfo;
		private System.Windows.Forms.DataGridView createOrder;
		private System.Windows.Forms.Label loginInfo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
		private System.Windows.Forms.DataGridViewTextBoxColumn Symbol;
		private System.Windows.Forms.DataGridViewComboBoxColumn BuySell;
		private System.Windows.Forms.DataGridViewTextBoxColumn Qty;
		private System.Windows.Forms.DataGridViewTextBoxColumn Price;
		private System.Windows.Forms.DataGridViewButtonColumn Send;
		private System.Windows.Forms.DataGridViewTextBoxColumn MyBidQty;
		private System.Windows.Forms.DataGridViewTextBoxColumn MktBidQty;
		private System.Windows.Forms.DataGridViewTextBoxColumn PriceOB;
		private System.Windows.Forms.DataGridViewTextBoxColumn MyAskQty;
		private System.Windows.Forms.DataGridViewTextBoxColumn MktAskQty;
	}
}

